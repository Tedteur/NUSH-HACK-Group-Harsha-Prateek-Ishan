package com.example.hackathon_2021.HostProgramme;

import java.awt.*;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;


public class InitConnection
{
    ServerSocket socket=null;
    DataInputStream password=null;
    DataOutputStream verify=null;
    String width="";
    String height="";

    InitConnection(int port,String value1)
    {
        //password in value1
        //awt Robo class used to generate native system input event
        //to test automation and self running demos (when connection established, say connection established)
        Robot robot=null;
        //rectangle used to specify area in coordinate space, from top left corner - need height and width
        Rectangle rectangle=null;
        try
        {
            System.out.println("waiting for client to connect");
            socket=new ServerSocket(port);
            //use graphic environment because it consists of a number of graphic devices, object and font object which might be in local or remote machine.
            GraphicsEnvironment gEnv=GraphicsEnvironment.getLocalGraphicsEnvironment();
            //graphics device class describes graphic devices that may be available in a particuar graphic environment. screen, printer device
            GraphicsDevice gDev=gEnv.getDefaultScreenDevice();
            //dimension in awt package - height and width of component in integer as well as double precision
            Dimension dim=Toolkit.getDefaultToolkit().getScreenSize();
            String width=""+dim.getWidth();
            String height=""+dim.getHeight();
            rectangle=new Rectangle(dim);
            robot=new Robot(gDev);

            drawGUI();
            while (true)
            {
                Socket sc=socket.accept();
                password=new DataInputStream(sc.getInputStream());
                verify=new DataOutputStream(sc.getOutputStream());

                String pssword = password.readUTF();
                //read utf of password as it will be in encoded format we will provide it in encoded from\
                if(password.equals(value1))
                {
                    verify.writeUTF("valid");
                    verify.writeUTF(width);
                    verify.writeUTF(height);
                    //left: send out screen after verifying credential & send the event-> create new class
                    new SendScreen(sc,robot,rectangle);
                    new ReceiveEvents(sc,robot);
                }
                else
                {
                    verify.writeUTF("Invalid");

                }
            }


        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    private void drawGUI()
    {
    }
}
