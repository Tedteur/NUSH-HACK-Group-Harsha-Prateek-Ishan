package com.example.hackathon_2021;

import com.example.hackathon_2021.HostProgramme.Start;
import com.example.hackathon_2021.UserProgramme.Main;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import org.w3c.dom.Text;

import javax.swing.*;
import java.io.*;
import java.nio.Buffer;
import java.util.Scanner;

public class HelloController {
    @FXML
    private Button hostGame;
    @FXML
    private Button joinGame;
    @FXML
    private Button leave;
    @FXML
    private Label hostLabel1;
    @FXML
    private Button lowP;
    @FXML
    private Button mediumP;
    @FXML
    private Button highP;
    @FXML
    private Label hostLabel2; //
    @FXML
    private Button mc;
    @FXML
    private Button fortnite;
    @FXML
    private Button rdr;
    @FXML
    private Button goBack1;
    @FXML
    private Label cost;
    @FXML
    private Label hostLabel3;
    @FXML
    private TextField ipAddress;
    @FXML
    private Button enterIP;
    @FXML
    private Button goBack2;
    @FXML
    private Label hostLabel4;
    @FXML
    private TextField mobileNo;
    @FXML
    private Button enterNo;
    @FXML
    private Button goBack3;
    @FXML
    private Button startHost;
    @FXML
    private Button stopHost;
    @FXML
    private Button cancelHost;
    @FXML
    private Label hostLabel5;
    @FXML
    private TextField name;
    @FXML
    private Button enterName;
    @FXML
    private Button goBack4;
    @FXML
    private Button startGame;
    @FXML
    private Button endGame;
    @FXML
    private Button cancelGame;
    private String processingPower;
    private String game;
    private double rate;
    private String ip;
    private String no;
    private String hostName;
    private String userWantsP;
    private String userWantsG;
    public void onLeave(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirm Leave");
        alert.setHeaderText("You are about to exit the app.");
        alert.setContentText("Are you sure you want to exit the app?");
        if (alert.showAndWait().get().equals(ButtonType.OK)) {
            Stage stage = (Stage) leave.getScene().getWindow();
            stage.close();
        }
    }
    public void hostGame(ActionEvent event){
        hostGame.setDisable(true);
        hostGame.setOpacity(0);
        joinGame.setDisable(true);
        joinGame.setOpacity(0);
        hostLabel1.setDisable(false);
        hostLabel1.setOpacity(1);
        hostLabel1.setText("Select your Processing Power:");
        lowP.setDisable(false);
        lowP.setOpacity(1);
        mediumP.setDisable(false);
        mediumP.setOpacity(1);
        highP.setDisable(false);
        highP.setOpacity(1);
        startHost.setOpacity(.5);
        stopHost.setOpacity(.5);
        cancelHost.setDisable(false);
        cancelHost.setOpacity(1);
        leave.setDisable(true);
        leave.setOpacity(0);
    }
    public void choosePower(ActionEvent event){
        if (hostLabel1.getText().equals("Select your Processing Power:")){
            cost.setOpacity(1);
            cost.setDisable(false);
                if (event.getSource().equals(lowP)){
                    cost.setText("You will receive $1.00/hour.");
                    rate = 1;
                    processingPower = "low";
                }
                else if (event.getSource().equals(mediumP)){
                    cost.setText("You will receive $2.00/hour.");
                    rate = 2;
                    processingPower = "medium";
                }
                else{
                    cost.setText("You will receive $3.00/hour.");
                    rate = 3;
                    processingPower = "high";
                }
            hostLabel1.setDisable(true);
            hostLabel1.setOpacity(0.5);
            lowP.setDisable(true);
            lowP.setOpacity(0.5);
            mediumP.setDisable(true);
            mediumP.setOpacity(0.5);
            highP.setDisable(true);
            highP.setOpacity(0.5);
            hostLabel2.setDisable(false);
            hostLabel2.setOpacity(1);
            hostLabel2.setText("Choose which game you want to host:");
            mc.setDisable(false);
            mc.setOpacity(1);
            fortnite.setDisable(false);
            fortnite.setOpacity(1);
            rdr.setDisable(false);
            rdr.setOpacity(1);
            goBack1.setDisable(false);
            goBack1.setOpacity(1);
        }
        else {
            if (event.getSource().equals(lowP)){
                userWantsP = "low";
            }
            else if (event.getSource().equals(mediumP)){
                userWantsP = "medium";
            }
            else{
                userWantsP = "high";
            }
            hostLabel1.setDisable(true);
            hostLabel1.setOpacity(0.5);
            lowP.setDisable(true);
            lowP.setOpacity(0.5);
            mediumP.setDisable(true);
            mediumP.setOpacity(0.5);
            highP.setDisable(true);
            highP.setOpacity(0.5);
            hostLabel2.setDisable(false);
            hostLabel2.setOpacity(1);
            hostLabel2.setText("What game do you want to play?");
            mc.setDisable(false);
            mc.setOpacity(1);
            fortnite.setDisable(false);
            fortnite.setOpacity(1);
            rdr.setDisable(false);
            rdr.setOpacity(1);
            goBack1.setDisable(false);
            goBack1.setOpacity(1);
        }
    }
    public void chooseGame(ActionEvent event){
        if (hostLabel2.getText().equals("What game do you want to play?")){
            double charge;
            if (event.getSource().equals(mc)){
                charge = 1;
                userWantsG = "Minecraft";
            }
            else if (event.getSource().equals(fortnite)){
                charge = 2;
                userWantsG = "Fortnite";
            }
            else {
                charge = 3;
                userWantsG = "Red Dead Redemption 2";
            }
            try{
                Scanner reader = new Scanner(new File("Users.csv"));
                String line = "";
                String[] parts;
                int counter = 0;
                while (reader.hasNext()){
                    line = reader.nextLine();
                    parts = line.split("[,]");
                    if (parts[1].equals(userWantsP) && parts[2].equals(userWantsG)) {
                        cost.setText("Name: " + parts[0] + ",  Rate: " + String.format("%.2f", charge) + ",  Mobile Phone Number: " + parts[5] + ",  IP Address: " + ip);
                        counter++;
                        break;
                    }
                }
                if (counter == 0){
                    cost.setText("No device available, please try again later!");
                    hostLabel2.setDisable(true);
                    hostLabel2.setOpacity(0.5);
                    mc.setDisable(true);
                    mc.setOpacity(0.5);
                    fortnite.setDisable(true);
                    fortnite.setOpacity(0.5);
                    rdr.setDisable(true);
                    rdr.setOpacity(0.5);
                    goBack1.setDisable(false);
                    goBack1.setOpacity(1);
                    cost.setOpacity(1);
                    cost.setDisable(true);
                }
                else{
                    hostLabel2.setDisable(true);
                    hostLabel2.setOpacity(0.5);
                    mc.setDisable(true);
                    mc.setOpacity(0.5);
                    fortnite.setDisable(true);
                    fortnite.setOpacity(0.5);
                    rdr.setDisable(true);
                    rdr.setOpacity(0.5);
                    goBack1.setDisable(false);
                    goBack1.setOpacity(1);
                    cost.setOpacity(1);
                    cost.setDisable(true);
                    startGame.setOpacity(1);
                    startGame.setDisable(false);
                }
            }
            catch(IOException e){
                e.printStackTrace();
            }
        }
        else{
            if (event.getSource().equals(mc)){
                game = "Minecraft";
            }
            else if (event.getSource().equals(fortnite)){
                game = "Fortnite";
            }
            else {
                game = "Red Dead Redemption 2";
            }
            hostLabel3.setDisable(false);
            hostLabel3.setOpacity(1);
            ipAddress.setText("");
            ipAddress.setDisable(false);
            ipAddress.setOpacity(1);
            enterIP.setDisable(false);
            enterIP.setOpacity(1);
            goBack2.setDisable(false);
            goBack2.setOpacity(1);
            hostLabel2.setDisable(true);
            hostLabel2.setOpacity(0.5);
            mc.setDisable(true);
            mc.setOpacity(0.5);
            fortnite.setDisable(true);
            fortnite.setOpacity(0.5);
            rdr.setDisable(true);
            rdr.setOpacity(0.5);
            goBack1.setDisable(true);
            goBack1.setOpacity(0.5);
        }
    }
    public void return1(ActionEvent event){
        hostLabel1.setOpacity(1);
        hostLabel1.setDisable(false);
        lowP.setOpacity(1);
        lowP.setDisable(false);
        mediumP.setOpacity(1);
        mediumP.setDisable(false);
        highP.setOpacity(1);
        highP.setDisable(false);
        hostLabel2.setDisable(true);
        hostLabel2.setOpacity(0);
        mc.setDisable(true);
        mc.setOpacity(0);
        fortnite.setDisable(true);
        fortnite.setOpacity(0);
        rdr.setDisable(true);
        rdr.setOpacity(0);
        goBack1.setDisable(true);
        goBack1.setOpacity(0);
        cost.setDisable(true);
        cost.setOpacity(0);
    }
    public void enterIP(ActionEvent event){
        ip = ipAddress.getText();
        hostLabel3.setDisable(true);
        hostLabel3.setOpacity(0.5);
        ipAddress.setDisable(true);
        ipAddress.setOpacity(0.5);
        enterIP.setDisable(true);
        enterIP.setOpacity(0.5);
        goBack2.setDisable(true);
        goBack2.setOpacity(0.5);
        hostLabel4.setDisable(false);
        hostLabel4.setOpacity(1.0);
        mobileNo.setText("");
        mobileNo.setDisable(false);
        mobileNo.setOpacity(1.0);
        enterNo.setDisable(false);
        enterNo.setOpacity(1.0);
        goBack3.setDisable(false);
        goBack3.setOpacity(1.0);
    }
    public void return2(ActionEvent event){
        hostLabel3.setDisable(true);
        hostLabel3.setOpacity(0);
        ipAddress.setDisable(true);
        ipAddress.setOpacity(0);
        enterIP.setDisable(true);
        enterIP.setOpacity(0);
        goBack2.setDisable(true);
        goBack2.setOpacity(0);
        hostLabel2.setDisable(false);
        hostLabel2.setOpacity(1);
        mc.setDisable(false);
        mc.setOpacity(1);
        fortnite.setDisable(false);
        fortnite.setOpacity(1);
        rdr.setDisable(false);
        rdr.setOpacity(1);
        goBack1.setDisable(false);
        goBack1.setOpacity(1);
    }
    public void enterNo(ActionEvent event){
        no = mobileNo.getText();
        hostLabel4.setDisable(true);
        hostLabel4.setOpacity(0.5);
        mobileNo.setOpacity(0.5);
        mobileNo.setDisable(true);
        enterNo.setOpacity(0.5);
        enterNo.setDisable(true);
        goBack3.setOpacity(0.5);
        goBack3.setDisable(true);
        hostLabel5.setDisable(false);
        hostLabel5.setOpacity(1.0);
        name.setDisable(false);
        name.setOpacity(1.0);
        enterName.setDisable(false);
        enterName.setOpacity(1.0);
        goBack4.setDisable(false);
        goBack4.setOpacity(1.0);
        name.setText("");
    }
    public void return3(ActionEvent event){
        hostLabel3.setDisable(false);
        hostLabel3.setOpacity(1);
        ipAddress.setDisable(false);
        ipAddress.setOpacity(1);
        enterIP.setDisable(false);
        enterIP.setOpacity(1);
        goBack2.setDisable(false);
        goBack2.setOpacity(1);
        hostLabel4.setOpacity(0);
        hostLabel4.setDisable(true);
        mobileNo.setOpacity(0);
        mobileNo.setDisable(true);
        enterNo.setOpacity(0);
        enterNo.setDisable(true);
        goBack3.setOpacity(0);
        goBack3.setDisable(true);
        startHost.setDisable(true);
        startHost.setOpacity(0.5);
    }
    public void enterName(ActionEvent event){
        hostName = name.getText();
        startHost.setOpacity(1);
        startHost.setDisable(false);
    }
    public void return4(ActionEvent event){
        hostLabel4.setOpacity(1.0);
        hostLabel4.setDisable(false);
        enterNo.setOpacity(1.0);
        enterNo.setDisable(false);
        mobileNo.setOpacity(1.0);
        mobileNo.setDisable(false);
        goBack3.setOpacity(1.0);
        goBack3.setDisable(false);
        hostLabel5.setOpacity(0);
        hostLabel5.setDisable(true);
        name.setOpacity(0);
        name.setDisable(true);
        enterName.setOpacity(0);
        enterName.setDisable(true);
        goBack4.setOpacity(0);
        goBack4.setDisable(true);
        startHost.setOpacity(0.5);
        startHost.setDisable(true);
    }
    public void startHost(ActionEvent event){
        User user = new User(processingPower, game, rate, ip, no, hostName);
        try{
            PrintWriter printer = new PrintWriter(new FileOutputStream("Users.csv", true));
            printer.println(user);
            printer.close();
        }
        catch (Exception e){
            System.out.println("File does not exist!");
        }
        hostLabel5.setOpacity(0.5);
        hostLabel5.setDisable(true);
        name.setOpacity(0.5);
        name.setDisable(true);
        enterName.setOpacity(0.5);
        enterName.setDisable(true);
        goBack4.setOpacity(0.5);
        goBack4.setDisable(true);
        stopHost.setDisable(false);
        stopHost.setOpacity(1);
        startHost.setDisable(false);
        startHost.setOpacity(0.5);
        cancelHost.setOpacity(0.5);
        cancelHost.setDisable(true);
        Start.main(null);
    }
    public void stopHost(ActionEvent event){
        try{
            Scanner reader = new Scanner(new File("Users.csv"));
            String line = "";
            String[] parts;
            String toBeCopied = "";
            while (reader.hasNext()){
                line = reader.nextLine();
                parts = line.split("[,]");
                if (!parts[4].equals(ip)) {
                    toBeCopied = toBeCopied + line + "\n";
                }
            }
            PrintWriter printer = new PrintWriter(new FileOutputStream("Users.csv"));
            printer.print(toBeCopied);
            printer.close();
        }
        catch (IOException e){
            System.out.println("File not found!");
        }
        startHost.setDisable(false);
        startHost.setOpacity(1.0);
        hostLabel5.setDisable(false);
        hostLabel5.setOpacity(1.0);
        name.setDisable(false);
        name.setOpacity(1.0);
        enterName.setDisable(false);
        enterName.setOpacity(1.0);
        goBack4.setDisable(false);
        goBack4.setOpacity(1.0);
        stopHost.setOpacity(0.5);
        stopHost.setDisable(true);
        cancelHost.setOpacity(1);
        cancelHost.setDisable(false);
    }
    public void cancel(ActionEvent event){
        hostLabel1.setDisable(true);
        hostLabel1.setOpacity(0);
        lowP.setDisable(true);
        lowP.setOpacity(0);
        mediumP.setDisable(true);
        mediumP.setOpacity(0);
        highP.setDisable(true);
        highP.setOpacity(0);
        hostLabel2.setDisable(true);
        hostLabel2.setOpacity(0);
        mc.setDisable(true);
        mc.setOpacity(0);
        fortnite.setDisable(true);
        fortnite.setOpacity(0);
        rdr.setDisable(true);
        rdr.setOpacity(0);
        cost.setDisable(true);
        cost.setOpacity(0);
        hostLabel3.setDisable(true);
        hostLabel3.setOpacity(0);
        ipAddress.setDisable(true);
        ipAddress.setOpacity(0);
        ipAddress.setText("");
        enterIP.setDisable(true);
        enterIP.setOpacity(0);
        goBack2.setDisable(true);
        goBack2.setOpacity(0);
        goBack1.setDisable(true);
        goBack1.setOpacity(0);
        hostLabel4.setDisable(true);
        hostLabel4.setOpacity(0);
        mobileNo.setDisable(true);
        mobileNo.setOpacity(0);
        mobileNo.setText("");
        enterNo.setDisable(true);
        enterNo.setOpacity(0);
        goBack3.setDisable(true);
        goBack3.setOpacity(0);
        hostLabel5.setDisable(true);
        hostLabel5.setOpacity(0);
        name.setDisable(true);
        name.setOpacity(0);
        name.setText("");
        enterName.setDisable(true);
        enterName.setOpacity(0);
        goBack4.setDisable(true);
        goBack4.setOpacity(0);
        startHost.setDisable(true);
        startHost.setOpacity(0);
        stopHost.setDisable(true);
        stopHost.setOpacity(0);
        leave.setDisable(false);
        leave.setOpacity(1);
        hostGame.setOpacity(1);
        hostGame.setDisable(false);
        joinGame.setOpacity(1);
        joinGame.setDisable(false);
        cancelHost.setOpacity(0);
        cancelHost.setDisable(true);
        startGame.setDisable(true);
        startGame.setOpacity(0);
        endGame.setOpacity(0);
        endGame.setDisable(true);
        cancelGame.setDisable(true);
        cancelGame.setOpacity(0);
    }
    public void joinGame(ActionEvent event){
        joinGame.setDisable(true);
        joinGame.setOpacity(0);
        hostGame.setDisable(true);
        hostGame.setOpacity(0);
        leave.setDisable(true);
        leave.setOpacity(0);
        hostLabel1.setText("What processing power do you prefer?");
        hostLabel1.setOpacity(1.0);
        hostLabel1.setDisable(false);
        lowP.setOpacity(1.0);
        lowP.setDisable(false);
        lowP.setTranslateX(-50);
        mediumP.setOpacity(1.0);
        mediumP.setDisable(false);
        mediumP.setTranslateX(30);
        highP.setOpacity(1.0);
        highP.setDisable(false);
        highP.setTranslateX(150);
        startGame.setOpacity(0.5);
        endGame.setOpacity(0.5);
        cancelGame.setOpacity(1);
        cancelGame.setDisable(false);
    }
    public void startGame(ActionEvent event){
        endGame.setDisable(false);
        endGame.setOpacity(1);
        startGame.setDisable(false);
        startGame.setOpacity(0.5);
        cancelGame.setOpacity(0.5);
        cancelGame.setDisable(true);
        goBack1.setOpacity(0.5);
        goBack1.setDisable(true);
        Main.main(null);
    }
    public void stopGame(ActionEvent event){
        endGame.setDisable(true);
        endGame.setOpacity(0.5);
        startGame.setDisable(false);
        startGame.setOpacity(1);
        cancelGame.setOpacity(1);
        cancelGame.setDisable(false);
        goBack1.setOpacity(1);
        goBack1.setDisable(false);
    }

}