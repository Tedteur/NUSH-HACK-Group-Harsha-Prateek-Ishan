package com.example.hackathon_2021.HostProgramme;

public class Start
{
    public static void main(String args[])
    {
        SetPassword frame1=new SetPassword();
        frame1.setSize(300,80); //view for ui
        frame1.setLocation(500,300);
        frame1.setVisible(true);

    }

}
