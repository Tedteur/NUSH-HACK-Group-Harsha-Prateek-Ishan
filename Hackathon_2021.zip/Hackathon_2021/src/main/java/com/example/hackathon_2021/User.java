package com.example.hackathon_2021;

public class User {
    private String processingPower;
    private String game;
    private Double rate;
    private String ip;
    private String phoneNo;
    private String name;
    public User(String processingPower, String game, Double rate, String ip, String phoneNo, String name){
        this.processingPower = processingPower;
        this.game = game;
        this.rate = rate;
        this.ip = ip;
        this.phoneNo = phoneNo;
        this.name = name;
    }
    public String toString(){
        return(name + "," + processingPower + "," + game + "," + rate + "," + ip + "," + phoneNo);
    }
}
