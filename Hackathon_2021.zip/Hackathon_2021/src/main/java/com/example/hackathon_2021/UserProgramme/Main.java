package com.example.hackathon_2021.UserProgramme;

import javax.swing.*;
import java.net.Socket;

public class Main
{
    static String port = "4907";

    public static void main(String[] args)
    {
        String ip = JOptionPane.showInputDialog("Please enter the host IP Address: ");
        new Main().initialize(ip, Integer.parseInt(port));
    }
    public void initialize(String ip, int port)
    {
        try
        {
            Socket sc = new Socket(ip, port);
            System.out.println("Please wait, connecting to server...");
            //system security and password
            Authentication frame1 = new Authentication(sc);
            frame1.setSize(300,80);
            frame1.setLocation(500,300);
            frame1.setVisible(true);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}

