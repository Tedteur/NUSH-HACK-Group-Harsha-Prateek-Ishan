module com.example.hackathon_2021 {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;
    requires java.desktop;


    opens com.example.hackathon_2021 to javafx.fxml;
    exports com.example.hackathon_2021;
}