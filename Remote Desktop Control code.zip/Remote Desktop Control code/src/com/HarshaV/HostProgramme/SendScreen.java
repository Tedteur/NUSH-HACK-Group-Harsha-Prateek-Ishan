package com.HarshaV.HostProgramme;

import com.HarshaV.HostProgramme.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import javax.imageio.ImageIO;

public class SendScreen extends Thread
{
    Socket socket=null;
    Robot robot=null;
    Rectangle rectangle=null;
    boolean continueLoop=true;
    OutputStream oos=null; //oos is object
    //predetermine variables used

    public SendScreen(Socket socket,Robot robot,Rectangle rect)
    //since we pass it from previous class, (sc, robot, rectangle), create here and initialize whole thing
    {
        this.socket=socket;
        this.robot=robot;
        rectangle=rect;
        new Start(); //everything related to this thread, send everything in the form of threading
    }
    public void run()
    {
        try
        {
            //initialize output stream
            oos = socket.getOutputStream();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        while(continueLoop)
        {
            //buffered image is sub class of image class. used to handle and manipulate user data
            BufferedImage image = robot.createScreenCapture(rectangle);
            try
            {
                ImageIO.write(image,"jpeg",oos);
            }
            catch(IOException e)
            {
                e.printStackTrace();
            }
            try
            {
                //slip the thread
                Thread.sleep(10);
            }
            catch(InterruptedException e)//when one thread is in sleeping mode and another thread interrupts this thread
            {
                e.printStackTrace();
            }

        }

    }

}

