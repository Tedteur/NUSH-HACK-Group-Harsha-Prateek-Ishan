package com.HarshaV.HostProgramme;

import com.HarshaV.HostProgramme.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public class Start
{
    public static void main(String args[])
    {
        SetPassword frame1=new SetPassword();
        frame1.setSize(300,80); //view for ui
        frame1.setLocation(500,300);
        frame1.setVisible(true);

    }

}
