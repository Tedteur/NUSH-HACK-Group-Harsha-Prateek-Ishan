package com.HarshaV.UserProgramme;

import javax.imageio.ImageIO;
import javax.swing.JPanel;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.awt.Image;
import java.awt.Graphics;
import java.io.ByteArrayInputStream;
//due to use in code below

//
class ReceivingScreen extends Thread
{
    //creating frame then extending thread
    //stream of screen of other device to be provided, => object input stream
    // reads object from file
    //used to convert input stream to object
    //cpanel: web hosting control panel  software that provides graphical interface and automation tools designed to simplify the process of hosting

    private ObjectInputStream cObjectInputStream=null;
    private JPanel cPanel=null;
    private boolean continueLoop=true;
    InputStream oin=null;
    Image image1=null; //take snapshot and pass from serverside

    //create constructor for this. => initialize everything (jpanel, inputstream)

    public ReceivingScreen(InputStream in, JPanel p)
    {
        oin=in;
        cPanel=p;
        start(); //start => run
    }
    public void run()
    {
        //continuously receive screen from server side => read the screen from server
        try {
            while (true) {
                //read screen in byte
                byte[] bytes = new byte[1024 * 1024];
                int count = 0;
                do {
                    //read this in input stream
                    count += oin.read(bytes, count, bytes.length - count);
                    //byte, count -> offset in array of byte at which data is written.
                    // length - data: amount of data read by input stream. if 0 ->nothing read ->return 0. if not 0 -> at least one byte read/
                    //string at end of file -> value returned is -1 -> update count. may give io exceptions so try and catch block
                } while (!(count > 4 && bytes[count - 2] == (byte) - 1 && bytes[count - 1] == (byte) -39));   //byte 0 = 00 00 00 00, byte -1= 11 11 1
                //have to check for another condition
                //count is offset starts from 0  go till length - count.
                image1 = ImageIO.read(new ByteArrayInputStream(bytes));
                //bytes as parameter
                image1 = image1.getScaledInstance(cPanel.getWidth(), cPanel.getHeight(), Image.SCALE_FAST);
                //scaledinstance-> 3 parameter, width-from cPanel, height, scaleimage
                //receive screen from our server side. -> use some graphics
                Graphics graphics = cPanel.getGraphics();
                graphics.drawImage(image1, 0, 0, cPanel.getWidth(), cPanel.getHeight(), cPanel);

            }
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }

    }
}
