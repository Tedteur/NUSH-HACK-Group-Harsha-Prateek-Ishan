package com.HarshaV.UserProgramme;

import com.HarshaV.UserProgramme.ReceivingScreen;
import com.HarshaV.UserProgramme.SendEvent;

import javax.swing.*;
import java.awt.*;
import java.beans.PropertyVetoException;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.util.zip.*;

// Creating code to project screen on user's PC
public class CreateFrame extends Thread
{
    String width = "", height = "";
    private JFrame frame = new JFrame();
    // contain all connected host screens
    private JDesktopPane desktop = new JDesktopPane();
    private Socket cSocket = null;
    // contain small windows screen including minimise maximise buttons
    private JInternalFrame interFrame = new JInternalFrame("Server Screen", true, true, true);
    private JPanel cPanel = new JPanel();
    public CreateFrame(Socket cSocket, String width, String height)
    {
        this.width = width;
        this.height= height;
        this.cSocket = cSocket;
        start();
    }
    public void drawGUI()
    {
        // frame settings
        frame.add(desktop, BorderLayout.CENTER);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // for maximised screen at start up
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setVisible(true);
        // adding interframe to desktop frame
        interFrame.setLayout(new BorderLayout());
        interFrame.setContentPane(cPanel);
        interFrame.add(cPanel, BorderLayout.CENTER);
        interFrame.setSize(100,100);
        desktop.add(interFrame);
        try
        {
            interFrame.setMaximum(true);
        }
        // if internal frame has change the host will deem it unacceptable
        catch (PropertyVetoException ex)
        {
            ex.printStackTrace();
        }
        cPanel.setFocusable(true);
        interFrame.setVisible(true);
    }

    public void run ()
    {
        // read host stream
        InputStream in = null;
        drawGUI();
        try
        {
            in = cSocket.getInputStream();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        // start receiving screen source
        new ReceivingScreen(in, cPanel);
        // class for host to receive user panel events (actions)
        new SendEvent(cSocket, cPanel, width, height);




}

}
